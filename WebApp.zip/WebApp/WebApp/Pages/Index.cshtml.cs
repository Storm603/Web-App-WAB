﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApp.Models;

namespace WebApp.Pages
{
    public class IndexModel : PageModel
    {
        private DBCtx Context { get; }
        public IndexModel(DBCtx _context)
        {
            this.Context = _context;
        }

        public List<Lane> Lanes { get; set; }

        public void OnGet()
        {
            this.Lanes = (from lane in this.Context.Lanes.Take(10)
                select lane).ToList();
        }
    }
    
}
