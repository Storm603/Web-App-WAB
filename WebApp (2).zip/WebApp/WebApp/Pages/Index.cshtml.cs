﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApp.Models;

namespace WebApp.Pages
{
    public class IndexModel : PageModel
    {
        private DBCtx Context { get; }
        public IndexModel(DBCtx _context)
        {
            this.Context = _context;
        }

        public List<LineInformation> Lanes { get; set; }
        public List<Data> Datas { get; set; }

        public void OnGet()
        {
            this.Lanes = (from lane in this.Context.Lane.Take(10)
                select lane).ToList();
            this.Datas = (from data in Context.Data.Take(10)
                select data).ToList();
        }
    }
    
}
