﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApp.Models
{
    public class LineInformation
    {
        public int Id { get; set; }
        public int PCT { get; set; }
        public string LineName { get; set; }
        public string Zone { get; set; }
        public int WorkPlace { get; set; }
        public int RealWorkPlace { get; set; }
        public double AreaBefore { get; set; }
    }
}
